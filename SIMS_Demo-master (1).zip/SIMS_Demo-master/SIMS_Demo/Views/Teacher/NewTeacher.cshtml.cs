using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SIMS_Demo.Views.Teacher
{
    public class NewTeacherModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
