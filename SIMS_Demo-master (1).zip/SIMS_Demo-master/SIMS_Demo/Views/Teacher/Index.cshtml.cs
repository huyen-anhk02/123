using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SIMS_Demo.Views.Teacher
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
